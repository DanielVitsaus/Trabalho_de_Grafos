var searchData=
[
  ['fechotransitivodireto',['fechoTransitivoDireto',['../class_grafo.html#aa5db00b08590804c1885d383ce67d1d2',1,'Grafo']]],
  ['fechotransitivoindireto',['fechoTransitivoIndireto',['../class_grafo.html#a568fd7e7ef01a0bb6e85b44999f519cd',1,'Grafo']]]
];
