var searchData=
[
  ['deletaitem',['deletaItem',['../class_lista.html#a32622b53bc0720338439beecd0e7972f',1,'Lista']]]
];
