var indexSectionsWithContent =
{
  0: "abcdefgiklmnoqrsv~",
  1: "agilv",
  2: "abcdefgiklmnoqrs~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

