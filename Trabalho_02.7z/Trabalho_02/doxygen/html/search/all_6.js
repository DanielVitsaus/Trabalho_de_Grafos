var searchData=
[
  ['geragrafotransposto',['geraGrafoTransposto',['../class_grafo.html#a363d5b79f8ab7aaa27dea38387e9ffb6',1,'Grafo']]],
  ['grafo',['Grafo',['../class_grafo.html',1,'Grafo'],['../class_grafo.html#ab810bbe26a98e9af6661ccddff66b03b',1,'Grafo::Grafo()'],['../class_grafo.html#ac389a7c921f396ed4ed0f296a90a649e',1,'Grafo::Grafo(bool dir)']]],
  ['grauno',['grauNo',['../class_grafo.html#a41ffeb7e79cf0d0c10297953f647c42d',1,'Grafo']]],
  ['gravaarquivo',['gravaArquivo',['../class_arquivo.html#a6ad97cf5bcb0e0ac4192aa35c5e2c357',1,'Arquivo::gravaArquivo(char *nomArquivo, vector&lt; vector&lt; int &gt; &gt;comForteConexo)'],['../class_arquivo.html#a793a1e9d97ba2beaca0219182f872638',1,'Arquivo::gravaArquivo(Grafo *g, char *nomArquivo, int nVertice, int nAresta, float grauMedio)']]]
];
