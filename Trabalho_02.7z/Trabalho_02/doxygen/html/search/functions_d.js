var searchData=
[
  ['quantcompconexo',['quantCompConexo',['../class_grafo.html#a42f883ece5986fcf8cbc4a8c793844f5',1,'Grafo']]],
  ['quantcompforteconexos',['quantCompForteConexos',['../class_grafo.html#ab64d335140e23a281f9600b764b6ed80',1,'Grafo']]]
];
