var searchData=
[
  ['removearesta',['removeAresta',['../class_vertice.html#a440a8735f0d7296bd9108951558bc30b',1,'Vertice::removeAresta()'],['../class_grafo.html#ab3a5abe0a30afac753120ce1587f6f65',1,'Grafo::removeAresta()']]],
  ['removeno',['removeNo',['../class_grafo.html#a1218362fe45c08e2a8d8729d5c45cbf7',1,'Grafo']]]
];
