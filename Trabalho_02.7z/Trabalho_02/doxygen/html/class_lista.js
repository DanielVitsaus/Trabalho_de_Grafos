var class_lista =
[
    [ "Lista", "class_lista.html#a1f668b36909182ef1360b48503529a31", null ],
    [ "adicionaItem", "class_lista.html#a0b1e9b3728bd4b9c6ef2d9c095dbb4f4", null ],
    [ "caminhaLista", "class_lista.html#acc446a0d931b922cbdf4a61794afe658", null ],
    [ "contaItems", "class_lista.html#ae006b01ac1cb5d6aba47acdc410db3f0", null ],
    [ "deletaItem", "class_lista.html#a32622b53bc0720338439beecd0e7972f", null ],
    [ "fimLista", "class_lista.html#a92efd69dea7b9b4caffcf9ebf12825ef", null ],
    [ "inicioLista", "class_lista.html#a21093c5b211072af96f8fda2e5739773", null ],
    [ "noIterator", "class_lista.html#afd444ac095ae137b6b43e5e575e54864", null ],
    [ "retornaLista", "class_lista.html#aabb1d795e42a01bb8c4d3271a922ed09", null ],
    [ "it", "class_lista.html#ace98919c6610731c124113bbf75fc659", null ],
    [ "nitems", "class_lista.html#a6d17539dfc71dde4df05343fcfefb8b0", null ],
    [ "pri", "class_lista.html#a7c35eadb33738c21dad896e957eff430", null ],
    [ "ult", "class_lista.html#ace7120ca6c36f648843bcd4a6991804d", null ]
];